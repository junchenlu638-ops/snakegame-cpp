#include "mainwindow.h"

#include <QKeyEvent>
#include <QRandomGenerator>
#include <QFont>
#include <QColor>
#include <QPen>
#include <QBrush>
#include <QString>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    musicPlayer = new QMediaPlayer(this);
    audioOutput = new QAudioOutput(this);

    musicPlayer->setAudioOutput(audioOutput);
    musicPlayer->setSource(QUrl::fromLocalFile("/Users/lujunchen/Desktop/snke/bgm.mp3"));

    audioOutput->setVolume(0.35);
    musicPlayer->setLoops(QMediaPlayer::Infinite);
    musicPlayer->play();
    setWindowTitle("Qt 贪吃蛇小游戏 - 熊出没主题预备版");
    setFocusPolicy(Qt::StrongFocus);
    setWindowState(Qt::WindowFullScreen);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateGame);

    initGame();
}

MainWindow::~MainWindow()
{
}

void MainWindow::initGame()
{
    snake.clear();
    foods.clear();
    obstacles.clear();

    int startX = ColCount / 2;
    int startY = RowCount / 2;

    snake.append(QPoint(startX, startY));
    snake.append(QPoint(startX - 1, startY));
    snake.append(QPoint(startX - 2, startY));

    direction = Right;
    nextDirection = Right;

    score = 0;
    stepCount = 0;
    gameState = StartState;
    gameMode = NormalMode;
    enemyMoveInterval = 2;

    enemy = QPoint(-1, -1);

    generateObstacles();
    generateFoods();

    enemy = generateRandomEmptyPoint();

    timer->start(120);
    update();
}

void MainWindow::startGame(GameMode mode)
{
    gameMode = mode;
    gameState = PlayingState;

    if (gameMode == NormalMode) {
        timer->start(120);
        enemyMoveInterval = 2;
    } else {
        timer->start(80);
        enemyMoveInterval = 1;
    }

    update();
}

bool MainWindow::pointInSnake(const QPoint &point)
{
    for (QPoint p : snake) {
        if (p == point) return true;
    }
    return false;
}

bool MainWindow::pointInFoods(const QPoint &point)
{
    for (QPoint p : foods) {
        if (p == point) return true;
    }
    return false;
}

bool MainWindow::pointInObstacles(const QPoint &point)
{
    for (QPoint p : obstacles) {
        if (p == point) return true;
    }
    return false;
}

QPoint MainWindow::generateRandomEmptyPoint()
{
    while (true) {
        int x = QRandomGenerator::global()->bounded(ColCount);
        int y = QRandomGenerator::global()->bounded(RowCount);

        QPoint point(x, y);

        if (!pointInSnake(point) &&
            !pointInFoods(point) &&
            !pointInObstacles(point) &&
            point != enemy) {
            return point;
        }
    }
}

void MainWindow::generateFoods()
{
    while (foods.size() < FoodCount) {
        foods.append(generateRandomEmptyPoint());
    }
}

void MainWindow::generateObstacles()
{
    while (obstacles.size() < ObstacleCount) {
        QPoint point = generateRandomEmptyPoint();

        int centerX = ColCount / 2;
        int centerY = RowCount / 2;

        int dx = point.x() - centerX;
        int dy = point.y() - centerY;

        if (dx < 0) dx = -dx;
        if (dy < 0) dy = -dy;

        if (dx <= 4 && dy <= 4) {
            continue;
        }

        obstacles.append(point);
    }
}

bool MainWindow::checkSnakeCollision(const QPoint &head)
{
    if (head.x() < 0 || head.x() >= ColCount ||
        head.y() < 0 || head.y() >= RowCount) {
        return true;
    }

    for (int i = 1; i < snake.size(); ++i) {
        if (snake[i] == head) return true;
    }

    if (pointInObstacles(head)) return true;
    if (head == enemy) return true;

    return false;
}

bool MainWindow::enemyHitSnake()
{
    for (QPoint p : snake) {
        if (p == enemy) return true;
    }
    return false;
}

void MainWindow::moveEnemyRandomly()
{
    QVector<QPoint> candidates;

    candidates.append(QPoint(enemy.x(), enemy.y() - 1));
    candidates.append(QPoint(enemy.x(), enemy.y() + 1));
    candidates.append(QPoint(enemy.x() - 1, enemy.y()));
    candidates.append(QPoint(enemy.x() + 1, enemy.y()));

    QVector<QPoint> validMoves;

    for (QPoint p : candidates) {
        if (p.x() >= 0 && p.x() < ColCount &&
            p.y() >= 0 && p.y() < RowCount &&
            !pointInObstacles(p)) {
            validMoves.append(p);
        }
    }

    if (validMoves.isEmpty()) return;

    int index = QRandomGenerator::global()->bounded(validMoves.size());
    enemy = validMoves[index];
}

void MainWindow::updateGame()
{
    if (gameState != PlayingState) {
        return;
    }

    stepCount++;
    direction = nextDirection;

    QPoint head = snake.first();
    QPoint newHead = head;

    if (direction == Up) {
        newHead.setY(head.y() - 1);
    } else if (direction == Down) {
        newHead.setY(head.y() + 1);
    } else if (direction == Left) {
        newHead.setX(head.x() - 1);
    } else if (direction == Right) {
        newHead.setX(head.x() + 1);
    }

    if (checkSnakeCollision(newHead)) {
        gameState = GameOverState;
        update();
        return;
    }

    snake.prepend(newHead);

    bool ateFood = false;

    for (int i = 0; i < foods.size(); ++i) {
        if (foods[i] == newHead) {
            foods.removeAt(i);
            score += 10;
            ateFood = true;
            break;
        }
    }

    if (!ateFood) {
        snake.removeLast();
    }

    generateFoods();

    if (stepCount % enemyMoveInterval == 0) {
        moveEnemyRandomly();
    }

    if (enemyHitSnake()) {
        gameState = GameOverState;
        update();
        return;
    }

    update();
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Escape) {
        close();
        return;
    }

    if (gameState == StartState) {
        if (event->key() == Qt::Key_1) {
            startGame(NormalMode);
            return;
        }

        if (event->key() == Qt::Key_2) {
            startGame(HardMode);
            return;
        }
    }

    if (event->key() == Qt::Key_P) {
        if (gameState == PlayingState) {
            gameState = PauseState;
            update();
        } else if (gameState == PauseState) {
            gameState = PlayingState;
            update();
        }
        return;
    }

    if (event->key() == Qt::Key_Space) {
        if (gameState == GameOverState) {
            initGame();
        }
        return;
    }

    if (gameState != PlayingState) {
        return;
    }

    if (event->key() == Qt::Key_Up || event->key() == Qt::Key_W) {
        if (direction != Down) nextDirection = Up;
    } else if (event->key() == Qt::Key_Down || event->key() == Qt::Key_S) {
        if (direction != Up) nextDirection = Down;
    } else if (event->key() == Qt::Key_Left || event->key() == Qt::Key_A) {
        if (direction != Right) nextDirection = Left;
    } else if (event->key() == Qt::Key_Right || event->key() == Qt::Key_D) {
        if (direction != Left) nextDirection = Right;
    }
}

int MainWindow::currentCellSize() const
{
    int availableWidth = width() - 120;
    int availableHeight = height() - 150;

    int cellByWidth = availableWidth / ColCount;
    int cellByHeight = availableHeight / RowCount;

    int cell = cellByWidth;

    if (cellByHeight < cell) {
        cell = cellByHeight;
    }

    if (cell < 10) {
        cell = 10;
    }

    return cell;
}

QRect MainWindow::boardRect() const
{
    int cell = currentCellSize();

    int boardWidth = ColCount * cell;
    int boardHeight = RowCount * cell;

    int x = (width() - boardWidth) / 2;
    int y = (height() - boardHeight) / 2 + 35;

    return QRect(x, y, boardWidth, boardHeight);
}

QRect MainWindow::cellRect(const QPoint &point, int padding) const
{
    QRect board = boardRect();
    int cell = currentCellSize();

    return QRect(
        board.x() + point.x() * cell + padding,
        board.y() + point.y() * cell + padding,
        cell - padding * 2,
        cell - padding * 2
        );
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    if (gameState == StartState) {
        drawStartScreen(painter);
    } else if (gameState == PlayingState) {
        drawGameScreen(painter);
    } else if (gameState == PauseState) {
        drawPauseScreen(painter);
    } else {
        drawGameOverScreen(painter);
    }
}

void MainWindow::drawStartScreen(QPainter &painter)
{
    QPixmap bg("/Users/lujunchen/Desktop/snke/images/forest.jpg");
    painter.drawPixmap(rect(), bg);

    QFont titleFont("Marker Felt", 64, QFont::Bold);
    painter.setFont(titleFont);

    painter.setPen(QColor(40,20,10,180));
    painter.drawText(
        QRect(4,height()/7+4,width(),90),
        Qt::AlignCenter,
        "森林小鸡贪吃蛇");

    painter.setPen(QColor(255,220,90));
    painter.setPen(QColor(255, 245, 180));
    painter.drawText(QRect(0, height() / 7, width(), 90), Qt::AlignCenter, "森林小鸡贪吃蛇");

    QFont subFont;
    subFont.setPointSize(20);
    painter.setFont(subFont);
    painter.setPen(QColor(80, 90, 110));
    painter.setPen(Qt::white);
    painter.drawText(QRect(0, height() / 7 + 90, width(), 50), Qt::AlignCenter, "C++ Qt 课程设计小游戏");
    int cardWidth = 700;
    int cardHeight = 360;
    int cardX = (width() - cardWidth) / 2;
    int cardY = height() / 2 - 150;

    QRect cardRect(cardX, cardY, cardWidth, cardHeight);

    painter.setBrush(QColor(255, 255, 255));
    painter.setPen(QPen(QColor(190, 205, 220), 3));
    painter.drawRoundedRect(cardRect, 24, 24);
    auto drawRuleText = [&](int y, QString text) {
        QFont ruleFont("Marker Felt", 25, QFont::Bold);
        painter.setFont(ruleFont);

        painter.setPen(QColor(255, 255, 255));
        painter.drawText(QRect(cardX + 57, y + 2, cardWidth - 110, 38),
                         Qt::AlignLeft, text);

     painter.setPen(QColor(70, 170, 100));
        painter.drawText(QRect(cardX + 55, y, cardWidth - 110, 38),
                         Qt::AlignLeft, text);
    };

    drawRuleText(cardY + 35,  "游戏规则：");
    drawRuleText(cardY + 80,  "1. 方向键 / WASD 控制蛇移动");
    drawRuleText(cardY + 120, "2. 吃红色食物加分，蛇身变长");
    drawRuleText(cardY + 160, "3. 避开灰色障碍物和紫色随机敌人");
    drawRuleText(cardY + 200, "4. 游戏中按 P 暂停 / 继续，Esc 退出");
    QFont modeFont("Marker Felt", 30, QFont::Bold);
    painter.setFont(modeFont);


    QString modeText = "按 1 普通模式    按 2 困难模式";

    // 阴影
    painter.setPen(QColor(30,40,80));
    painter.drawText(
        QRect(cardX+57, cardY+262, cardWidth-110,40),
        Qt::AlignCenter,
        modeText);

    // 金色艺术字
    painter.setPen(QColor(255,220,80));
    painter.drawText(
        QRect(cardX+55, cardY+260, cardWidth-110,40),
        Qt::AlignCenter,
        modeText);
    QFont tipFont;
    tipFont.setPointSize(15);
    tipFont.setBold(false);
    painter.setFont(tipFont);
    painter.setPen(QColor(100, 100, 100));
    painter.drawText(QRect(0, height() - 80, width(), 40),
                     Qt::AlignCenter, "困难模式：蛇移动更快，敌人移动更快");
}

void MainWindow::drawGameScreen(QPainter &painter)
{
    QPixmap bg("/Users/lujunchen/Desktop/snke/images/forest.jpg");
    painter.drawPixmap(rect(), bg);
    QRect board = boardRect();
    int cell = currentCellSize();

    QRect infoBar(0, 0, width(), 70);
    painter.fillRect(infoBar, QColor(35, 55, 85));

    QFont scoreFont;
    scoreFont.setPointSize(18);
    scoreFont.setBold(true);
    painter.setFont(scoreFont);
    painter.setPen(QColor(255, 255, 255));

    QString modeText = (gameMode == NormalMode) ? "Mode: Normal" : "Mode: Hard";

    painter.drawText(40, 43, QString("Score: %1").arg(score));
    painter.drawText(210, 43, QString("Food: %1").arg(foods.size()));
    painter.drawText(360, 43, QString("Obstacles: %1").arg(obstacles.size()));
    painter.drawText(590, 43, "Enemy: Random");
    painter.drawText(800, 43, modeText);
    painter.drawText(width() - 260, 43, "P 暂停    Esc 退出");

    painter.setBrush(QColor(250, 252, 255));
    painter.setPen(QPen(QColor(180, 195, 215), 3));
    painter.drawRoundedRect(board.adjusted(-4, -4, 4, 4), 12, 12);

    painter.setPen(QPen(QColor(220, 226, 235), 1));

    for (int x = 0; x <= ColCount; ++x) {
        int px = board.x() + x * cell;
        painter.drawLine(px, board.y(), px, board.y() + board.height());
    }

    for (int y = 0; y <= RowCount; ++y) {
        int py = board.y() + y * cell;
        painter.drawLine(board.x(), py, board.x() + board.width(), py);
    }

    painter.setPen(Qt::NoPen);

    for (QPoint obstacle : obstacles) {
        QRect obstacleRect = cellRect(obstacle, 3);
        QPixmap bee("/Users/lujunchen/Desktop/snke/images/bee.png");
        painter.drawPixmap(obstacleRect, bee);
    }

    for (QPoint food : foods) {
        QRect foodRect = cellRect(food, 5);
        QPixmap apple("/Users/lujunchen/Desktop/snke/images/apple.png");
        painter.drawPixmap(foodRect, apple);
    }

    QRect enemyRect = cellRect(enemy, 4);
    QPixmap bear("/Users/lujunchen/Desktop/snke/images/bear.png");
    QRect bigEnemyRect(
        enemyRect.x() - enemyRect.width() / 2,
        enemyRect.y() - enemyRect.height() / 2,
        enemyRect.width() * 2,
        enemyRect.height() * 2
        );

    painter.drawPixmap(bigEnemyRect, bear);

    for (int i = 0; i < snake.size(); ++i) {
        QRect snakeRect = cellRect(snake[i], 3);

        for (int i = 0; i < snake.size(); ++i) {
            QRect snakeRect = cellRect(snake[i], 3);

            QPixmap chick("/Users/lujunchen/Desktop/snke/images/chick.png");
            painter.drawPixmap(snakeRect, chick);
        }
    }
}

void MainWindow::drawPauseScreen(QPainter &painter)
{
    drawGameScreen(painter);

    painter.fillRect(rect(), QColor(0, 0, 0, 120));

    int cardWidth = 560;
    int cardHeight = 220;
    int cardX = (width() - cardWidth) / 2;
    int cardY = (height() - cardHeight) / 2;

    QRect cardRect(cardX, cardY, cardWidth, cardHeight);

    painter.setBrush(QColor(255, 255, 255));
    painter.setPen(QPen(QColor(46, 134, 222), 4));
    painter.drawRoundedRect(cardRect, 28, 28);

    QFont titleFont;
    titleFont.setPointSize(38);
    titleFont.setBold(true);
    painter.setFont(titleFont);
    painter.setPen(QColor(46, 134, 222));
    painter.drawText(QRect(cardX, cardY + 35, cardWidth, 70),
                     Qt::AlignCenter, "游戏暂停");

    QFont tipFont;
    tipFont.setPointSize(20);
    tipFont.setBold(false);
    painter.setFont(tipFont);
    painter.setPen(QColor(80, 80, 80));
    painter.drawText(QRect(cardX, cardY + 125, cardWidth, 50),
                     Qt::AlignCenter, "按 P 继续游戏");
}

void MainWindow::drawGameOverScreen(QPainter &painter)
{
    drawGameScreen(painter);

    painter.fillRect(rect(), QColor(0, 0, 0, 135));

    int cardWidth = 620;
    int cardHeight = 310;
    int cardX = (width() - cardWidth) / 2;
    int cardY = (height() - cardHeight) / 2;

    QRect cardRect(cardX, cardY, cardWidth, cardHeight);

    painter.setBrush(QColor(255, 255, 255));
    painter.setPen(QPen(QColor(220, 70, 90), 4));
    painter.drawRoundedRect(cardRect, 28, 28);

    QFont titleFont;
    titleFont.setPointSize(38);
    titleFont.setBold(true);
    painter.setFont(titleFont);
    painter.setPen(QColor(220, 53, 69));
    painter.drawText(QRect(cardX, cardY + 35, cardWidth, 70),
                     Qt::AlignCenter, "游戏结束");

    QFont scoreFont;
    scoreFont.setPointSize(26);
    scoreFont.setBold(true);
    painter.setFont(scoreFont);
    painter.setPen(QColor(40, 40, 40));
    painter.drawText(QRect(cardX, cardY + 125, cardWidth, 60),
                     Qt::AlignCenter, QString("最终得分：%1").arg(score));

    QFont tipFont;
    tipFont.setPointSize(20);
    tipFont.setBold(false);
    painter.setFont(tipFont);
    painter.setPen(QColor(80, 80, 80));
    painter.drawText(QRect(cardX, cardY + 210, cardWidth, 45),
                     Qt::AlignCenter, "按空格回到开始界面，按 Esc 退出");
}