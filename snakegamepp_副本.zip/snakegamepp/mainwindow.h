#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QMainWindow>
#include <QTimer>
#include <QVector>
#include <QPoint>
#include <QPainter>
#include <QRect>
#include <QUrl>
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void updateGame();

private:
    QMediaPlayer *musicPlayer;
    QAudioOutput *audioOutput;
    enum Direction { Up, Down, Left, Right };
    enum GameState { StartState, PlayingState, PauseState, GameOverState };
    enum GameMode { NormalMode, HardMode };

    void initGame();
    void startGame(GameMode mode);

    void generateFoods();
    void generateObstacles();
    QPoint generateRandomEmptyPoint();

    bool pointInSnake(const QPoint &point);
    bool pointInFoods(const QPoint &point);
    bool pointInObstacles(const QPoint &point);
    bool checkSnakeCollision(const QPoint &head);

    void moveEnemyRandomly();
    bool enemyHitSnake();

    int currentCellSize() const;
    QRect boardRect() const;
    QRect cellRect(const QPoint &point, int padding) const;

    void drawStartScreen(QPainter &painter);
    void drawGameScreen(QPainter &painter);
    void drawPauseScreen(QPainter &painter);
    void drawGameOverScreen(QPainter &painter);

private:
    static const int RowCount = 25;
    static const int ColCount = 30;
    static const int FoodCount = 15;
    static const int ObstacleCount = 35;

    QTimer *timer;

    QVector<QPoint> snake;
    QVector<QPoint> foods;
    QVector<QPoint> obstacles;

    QPoint enemy;

    Direction direction;
    Direction nextDirection;
    GameState gameState;
    GameMode gameMode;

    int score;
    int stepCount;
    int enemyMoveInterval;
};

#endif